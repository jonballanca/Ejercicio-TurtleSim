import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist
import math


class SubscriberAndPublisher(Node):
    def __init__(self, dX, dY):
        super().__init__('subscriber_and_publisher')
        self.destX = dX
        self.destY = dY

        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0

        self.state = 0
        self.angleGoal = 0.0

        self.subscription = self.create_subscription(
            Pose,
            '/turtle1/pose',
            self.callback_subscriber,
            10)
        self.subscription

        self.publisher_ = self.create_publisher(
            Twist,
            '/turtle1/cmd_vel',
            10)
        timer_period = 0.0001  # seconds
        self.timer = self.create_timer(timer_period, self.callback_timer)

    def callback_timer(self):
        twist = Twist()

        if self.state == 0:
            self.angleGoal = calculate_angle(self.x, self.y, self.destX, self.destY)
            print("\nCurrent angle goal is: ", self.angleGoal)
            print("\nCurrent angle: ", self.theta)

            if abs(self.angleGoal - self.theta) > 0.1:
                twist.angular.z = 0.5
            else:
                self.state = 1

        elif self.state == 1:
            print("\nCurrent angle goal is: ", self.angleGoal)
            print("\nCurrent angle: ", self.theta)
            print("\nState: ", self.state)
            if abs(self.angleGoal - self.theta) > 0.01:
                twist.angular.z = 0.24
            else:
                self.state = 2

        elif self.state == 2:
            print("\nCurrent angle goal is: ", self.angleGoal)
            print("\nCurrent angle: ", self.theta)
            print("\nState: ", self.state)
            if abs(self.angleGoal - self.theta) > 0.001:
                twist.angular.z = 0.003
            else:
                self.state = 3

        elif self.state == 3:
            print("\nCurrent angle goal is: ", self.angleGoal)
            print("\nCurrent angle: ", self.theta)
            print("\nState: ", self.state)
            if abs(self.angleGoal - self.theta) > 0.000001:
                twist.angular.z = 0.0005
            else:
                self.state = 4

        elif self.state == 4:
            if (round(self.x, 1) != round(self.destX, 1)) and (round(self.y, 1) != round(self.destY, 1)):
                twist.linear.x = 0.5
            else:
                twist.linear.x = 0.0

                print("\nCurrent position is: ", self.x, self.y)

                self.destX = float(input("\nDestination X: "))
                self.destY = float(input("Destination Y: "))
                self.state = 0



        self.publisher_.publish(twist)

    def callback_subscriber(self, msg):
        self.x = msg.x
        self.y = msg.y
        self.theta = msg.theta


def calculate_angle(x, y, destX, destY):
    xCath = (destX - x)
    yCath = (destY - y)

    angle = math.atan2(yCath, xCath)

    return angle


def main(args=None):
    rclpy.init(args=args)

    destX = float(input("Destination X: "))
    destY = float(input("Destination Y: "))

    subscriberAndPublisher = SubscriberAndPublisher(destX, destY)
    rclpy.spin(subscriberAndPublisher)


if __name__ == '__main__':
    main()


